package br.com.estagiotechb2w.estagiotechb2w;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Estagiotechb2wApplicationTests {

	@Test
	void contextLoads() {
	}

}
