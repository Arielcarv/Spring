package br.com.estagiotechb2w.estagiotechb2w;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Estagiotechb2wApplication {

	public static void main(String[] args) {
		SpringApplication.run(Estagiotechb2wApplication.class, args);
	}

}
